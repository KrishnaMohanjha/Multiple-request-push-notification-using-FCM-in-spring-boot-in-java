package com.push.notification.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.MessagingErrorCode;
import com.google.firebase.messaging.Notification;
import com.push.notification.entity.User;

@Service
public class UserService {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserService.class);

    public String sendNotification(User user) {
        Notification notification = Notification.builder()
                .setTitle(user.getTitle())
                .setBody(user.getMessage())
                .build();

        Message message = Message.builder()
                .setToken(user.getToken())
                .setNotification(notification)
                .build();

        try {
            String response = FirebaseMessaging.getInstance().send(message);
            LOGGER.info("Notification sent successfully to " + user.getToken() + ". Response: " + response);
            return response;
        } catch (FirebaseMessagingException e) {
            if (e.getMessagingErrorCode() == MessagingErrorCode.UNREGISTERED) {
                LOGGER.warn("Invalid or unregistered token: " + user.getToken());
                // Optionally remove the invalid token from the database
                // tokenRepository.deleteByToken(user.getToken());
                return "Error: Unregistered or invalid token for " + user.getToken();
            } else {
                LOGGER.error("Error occurred while sending notification to " + user.getToken() + ": ", e);
                return "Error: " + e.getMessage();
            }
        }
    }
}