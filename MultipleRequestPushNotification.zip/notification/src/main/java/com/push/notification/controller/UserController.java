package com.push.notification.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.push.notification.configuration.ResponseHandler;
import com.push.notification.entity.User;
import com.push.notification.service.UserService;

@RestController
@RequestMapping("/api")
public class UserController {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @PostMapping("/pushNotifications")
    public ResponseEntity<Object> pushNotifications(@RequestBody List<User> users) {
        List<String> responses = new ArrayList<>();
        List<String> errors = new ArrayList<>();

        for (User user : users) {
            try {
                String result = userService.sendNotification(user);
                responses.add(result);
            } catch (Exception e) {
                LOGGER.error("Error occurred while sending notification: ", e);
                //errors.add("Error occurred while sending notification to user: " + user.getEmail());
            }
        }

        if (errors.isEmpty()) {
            return ResponseHandler.generateResponse("All notifications sent successfully", HttpStatus.OK, responses);
        } else {
            return ResponseHandler.generateResponse("Some notifications failed", HttpStatus.PARTIAL_CONTENT, responses);
        }
    }
}